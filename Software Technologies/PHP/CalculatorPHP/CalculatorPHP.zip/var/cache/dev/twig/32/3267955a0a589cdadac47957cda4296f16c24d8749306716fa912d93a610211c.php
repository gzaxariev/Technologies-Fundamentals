<?php

/* base.html.twig */
class __TwigTemplate_4bbe4cb00ce6f8d465c8dd6727bc2b9ec28634a7580dd9013cb65806d5629e1e extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = array(
            'title' => array($this, 'block_title'),
            'stylesheets' => array($this, 'block_stylesheets'),
            'body_id' => array($this, 'block_body_id'),
            'header' => array($this, 'block_header'),
            'body' => array($this, 'block_body'),
            'main' => array($this, 'block_main'),
            'footer' => array($this, 'block_footer'),
            'javascripts' => array($this, 'block_javascripts'),
        );
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_38d727eca10694bbd3eb53de592bf5e83137f22ddd614ae49accf7924da0e8a5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_38d727eca10694bbd3eb53de592bf5e83137f22ddd614ae49accf7924da0e8a5->enter($__internal_38d727eca10694bbd3eb53de592bf5e83137f22ddd614ae49accf7924da0e8a5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        $__internal_2814c03f27c64b3ca0c7494a2d0f1b2ec21d1dd794d193600a584e12cfe34d95 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_2814c03f27c64b3ca0c7494a2d0f1b2ec21d1dd794d193600a584e12cfe34d95->enter($__internal_2814c03f27c64b3ca0c7494a2d0f1b2ec21d1dd794d193600a584e12cfe34d95_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "base.html.twig"));

        // line 6
        echo "<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>";
        // line 11
        $this->displayBlock('title', $context, $blocks);
        echo "</title>
    ";
        // line 12
        $this->displayBlock('stylesheets', $context, $blocks);
        // line 16
        echo "    <link rel=\"icon\" type=\"image/x-icon\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("favicon.ico"), "html", null, true);
        echo "\"/>
</head>

<body id=\"";
        // line 19
        $this->displayBlock('body_id', $context, $blocks);
        echo "\">

";
        // line 21
        $this->displayBlock('header', $context, $blocks);
        // line 39
        echo "
<div class=\"container body-container\">
    ";
        // line 41
        $this->displayBlock('body', $context, $blocks);
        // line 48
        echo "</div>

";
        // line 50
        $this->displayBlock('footer', $context, $blocks);
        // line 57
        echo "
";
        // line 58
        $this->displayBlock('javascripts', $context, $blocks);
        // line 64
        echo "
</body>
</html>
";
        
        $__internal_38d727eca10694bbd3eb53de592bf5e83137f22ddd614ae49accf7924da0e8a5->leave($__internal_38d727eca10694bbd3eb53de592bf5e83137f22ddd614ae49accf7924da0e8a5_prof);

        
        $__internal_2814c03f27c64b3ca0c7494a2d0f1b2ec21d1dd794d193600a584e12cfe34d95->leave($__internal_2814c03f27c64b3ca0c7494a2d0f1b2ec21d1dd794d193600a584e12cfe34d95_prof);

    }

    // line 11
    public function block_title($context, array $blocks = array())
    {
        $__internal_02f42cf730e0885798b5f29e19c380664f0c18ad133c403d5545900b928fcfec = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_02f42cf730e0885798b5f29e19c380664f0c18ad133c403d5545900b928fcfec->enter($__internal_02f42cf730e0885798b5f29e19c380664f0c18ad133c403d5545900b928fcfec_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        $__internal_ab1f5b0578bb3f6ad7cd87534300ad64d3ebe9a9dd6ad2cb471c598d05dfddaf = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ab1f5b0578bb3f6ad7cd87534300ad64d3ebe9a9dd6ad2cb471c598d05dfddaf->enter($__internal_ab1f5b0578bb3f6ad7cd87534300ad64d3ebe9a9dd6ad2cb471c598d05dfddaf_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "title"));

        echo "Calculator";
        
        $__internal_ab1f5b0578bb3f6ad7cd87534300ad64d3ebe9a9dd6ad2cb471c598d05dfddaf->leave($__internal_ab1f5b0578bb3f6ad7cd87534300ad64d3ebe9a9dd6ad2cb471c598d05dfddaf_prof);

        
        $__internal_02f42cf730e0885798b5f29e19c380664f0c18ad133c403d5545900b928fcfec->leave($__internal_02f42cf730e0885798b5f29e19c380664f0c18ad133c403d5545900b928fcfec_prof);

    }

    // line 12
    public function block_stylesheets($context, array $blocks = array())
    {
        $__internal_aad33205fbc172ad087e4b6a1e6e2fc89d2be3e07b6f27a22fd06533615aa05a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_aad33205fbc172ad087e4b6a1e6e2fc89d2be3e07b6f27a22fd06533615aa05a->enter($__internal_aad33205fbc172ad087e4b6a1e6e2fc89d2be3e07b6f27a22fd06533615aa05a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        $__internal_ec5fad91cf37267ff8c57c1b9538dc9877fd6445fbd3ae1653c231ffc010774c = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ec5fad91cf37267ff8c57c1b9538dc9877fd6445fbd3ae1653c231ffc010774c->enter($__internal_ec5fad91cf37267ff8c57c1b9538dc9877fd6445fbd3ae1653c231ffc010774c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "stylesheets"));

        // line 13
        echo "        <link rel=\"stylesheet\" href=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/style.css"), "html", null, true);
        echo "\">
        <link rel=\"stylesheet\" href=\"";
        // line 14
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("css/bootstrap-datetimepicker.min.css"), "html", null, true);
        echo "\">
    ";
        
        $__internal_ec5fad91cf37267ff8c57c1b9538dc9877fd6445fbd3ae1653c231ffc010774c->leave($__internal_ec5fad91cf37267ff8c57c1b9538dc9877fd6445fbd3ae1653c231ffc010774c_prof);

        
        $__internal_aad33205fbc172ad087e4b6a1e6e2fc89d2be3e07b6f27a22fd06533615aa05a->leave($__internal_aad33205fbc172ad087e4b6a1e6e2fc89d2be3e07b6f27a22fd06533615aa05a_prof);

    }

    // line 19
    public function block_body_id($context, array $blocks = array())
    {
        $__internal_05bd4f8efd024966dc4e9c24aff5fa93afb32f34cf2a1643b33899493d9235b5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_05bd4f8efd024966dc4e9c24aff5fa93afb32f34cf2a1643b33899493d9235b5->enter($__internal_05bd4f8efd024966dc4e9c24aff5fa93afb32f34cf2a1643b33899493d9235b5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        $__internal_600e9f4b59a1dd341d583cf1888e0d373248925d66a2c52b9a8a8c65c88110c1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_600e9f4b59a1dd341d583cf1888e0d373248925d66a2c52b9a8a8c65c88110c1->enter($__internal_600e9f4b59a1dd341d583cf1888e0d373248925d66a2c52b9a8a8c65c88110c1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body_id"));

        
        $__internal_600e9f4b59a1dd341d583cf1888e0d373248925d66a2c52b9a8a8c65c88110c1->leave($__internal_600e9f4b59a1dd341d583cf1888e0d373248925d66a2c52b9a8a8c65c88110c1_prof);

        
        $__internal_05bd4f8efd024966dc4e9c24aff5fa93afb32f34cf2a1643b33899493d9235b5->leave($__internal_05bd4f8efd024966dc4e9c24aff5fa93afb32f34cf2a1643b33899493d9235b5_prof);

    }

    // line 21
    public function block_header($context, array $blocks = array())
    {
        $__internal_4b032f88ced450b00da2a7cc7b0bf373b2b78668f1e38df5c9a1ca4870cd4c79 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_4b032f88ced450b00da2a7cc7b0bf373b2b78668f1e38df5c9a1ca4870cd4c79->enter($__internal_4b032f88ced450b00da2a7cc7b0bf373b2b78668f1e38df5c9a1ca4870cd4c79_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        $__internal_138a26ef3fba7f164a6d4a48852778b239ea52c3ed7c1a6030d1e217a43052fc = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_138a26ef3fba7f164a6d4a48852778b239ea52c3ed7c1a6030d1e217a43052fc->enter($__internal_138a26ef3fba7f164a6d4a48852778b239ea52c3ed7c1a6030d1e217a43052fc_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "header"));

        // line 22
        echo "    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"";
        // line 26
        echo $this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("index");
        echo "\" class=\"navbar-brand\">CALCULATOR</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>

            </div>
        </div>
    </header>
";
        
        $__internal_138a26ef3fba7f164a6d4a48852778b239ea52c3ed7c1a6030d1e217a43052fc->leave($__internal_138a26ef3fba7f164a6d4a48852778b239ea52c3ed7c1a6030d1e217a43052fc_prof);

        
        $__internal_4b032f88ced450b00da2a7cc7b0bf373b2b78668f1e38df5c9a1ca4870cd4c79->leave($__internal_4b032f88ced450b00da2a7cc7b0bf373b2b78668f1e38df5c9a1ca4870cd4c79_prof);

    }

    // line 41
    public function block_body($context, array $blocks = array())
    {
        $__internal_9239ca7a94ccf8122ae502b614ebd9c0c13d4a974f3095e9f2b852d1779bb7b9 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_9239ca7a94ccf8122ae502b614ebd9c0c13d4a974f3095e9f2b852d1779bb7b9->enter($__internal_9239ca7a94ccf8122ae502b614ebd9c0c13d4a974f3095e9f2b852d1779bb7b9_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        $__internal_5e260b53cfe3d8520d1ed75d2f4fb8c3a273d59be7f219bd073a7442fcbb42ef = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_5e260b53cfe3d8520d1ed75d2f4fb8c3a273d59be7f219bd073a7442fcbb42ef->enter($__internal_5e260b53cfe3d8520d1ed75d2f4fb8c3a273d59be7f219bd073a7442fcbb42ef_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "body"));

        // line 42
        echo "        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                ";
        // line 44
        $this->displayBlock('main', $context, $blocks);
        // line 45
        echo "            </div>
        </div>
    ";
        
        $__internal_5e260b53cfe3d8520d1ed75d2f4fb8c3a273d59be7f219bd073a7442fcbb42ef->leave($__internal_5e260b53cfe3d8520d1ed75d2f4fb8c3a273d59be7f219bd073a7442fcbb42ef_prof);

        
        $__internal_9239ca7a94ccf8122ae502b614ebd9c0c13d4a974f3095e9f2b852d1779bb7b9->leave($__internal_9239ca7a94ccf8122ae502b614ebd9c0c13d4a974f3095e9f2b852d1779bb7b9_prof);

    }

    // line 44
    public function block_main($context, array $blocks = array())
    {
        $__internal_992d903d42005a47f68f26814e593bcc48921c7462754f8fead954601c2f79ab = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_992d903d42005a47f68f26814e593bcc48921c7462754f8fead954601c2f79ab->enter($__internal_992d903d42005a47f68f26814e593bcc48921c7462754f8fead954601c2f79ab_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        $__internal_739a7a7a2254db48be5bfca1918e51b0ee6649dfc87c8b5d7a5e3e0ee79425f1 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_739a7a7a2254db48be5bfca1918e51b0ee6649dfc87c8b5d7a5e3e0ee79425f1->enter($__internal_739a7a7a2254db48be5bfca1918e51b0ee6649dfc87c8b5d7a5e3e0ee79425f1_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "main"));

        
        $__internal_739a7a7a2254db48be5bfca1918e51b0ee6649dfc87c8b5d7a5e3e0ee79425f1->leave($__internal_739a7a7a2254db48be5bfca1918e51b0ee6649dfc87c8b5d7a5e3e0ee79425f1_prof);

        
        $__internal_992d903d42005a47f68f26814e593bcc48921c7462754f8fead954601c2f79ab->leave($__internal_992d903d42005a47f68f26814e593bcc48921c7462754f8fead954601c2f79ab_prof);

    }

    // line 50
    public function block_footer($context, array $blocks = array())
    {
        $__internal_d40d70f579ba501b10d77ebb107058385a16c45df1b382f9adc61fbfedde0c14 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_d40d70f579ba501b10d77ebb107058385a16c45df1b382f9adc61fbfedde0c14->enter($__internal_d40d70f579ba501b10d77ebb107058385a16c45df1b382f9adc61fbfedde0c14_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        $__internal_ef8b1a44836fc8165ec1c6639d19e7e7b251260bf2cbe6e01c129fd0189a9cff = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_ef8b1a44836fc8165ec1c6639d19e7e7b251260bf2cbe6e01c129fd0189a9cff->enter($__internal_ef8b1a44836fc8165ec1c6639d19e7e7b251260bf2cbe6e01c129fd0189a9cff_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "footer"));

        // line 51
        echo "    <footer>
        <div class=\"container modal-footer\">
            <p>&copy; 2018 - Software University Foundation</p>
        </div>
    </footer>
";
        
        $__internal_ef8b1a44836fc8165ec1c6639d19e7e7b251260bf2cbe6e01c129fd0189a9cff->leave($__internal_ef8b1a44836fc8165ec1c6639d19e7e7b251260bf2cbe6e01c129fd0189a9cff_prof);

        
        $__internal_d40d70f579ba501b10d77ebb107058385a16c45df1b382f9adc61fbfedde0c14->leave($__internal_d40d70f579ba501b10d77ebb107058385a16c45df1b382f9adc61fbfedde0c14_prof);

    }

    // line 58
    public function block_javascripts($context, array $blocks = array())
    {
        $__internal_fa261fada51624c460a2443c0900a3ccf1757fe773e371473870d801244fc16f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_fa261fada51624c460a2443c0900a3ccf1757fe773e371473870d801244fc16f->enter($__internal_fa261fada51624c460a2443c0900a3ccf1757fe773e371473870d801244fc16f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        $__internal_add0ceff660eb97f6b4dde63065278b5086ecc4faaebb6d4a88115cc662ed340 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_add0ceff660eb97f6b4dde63065278b5086ecc4faaebb6d4a88115cc662ed340->enter($__internal_add0ceff660eb97f6b4dde63065278b5086ecc4faaebb6d4a88115cc662ed340_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "javascripts"));

        // line 59
        echo "    <script src=\"";
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/jquery-2.2.4.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 60
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/moment.min.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 61
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap.js"), "html", null, true);
        echo "\"></script>
    <script src=\"";
        // line 62
        echo twig_escape_filter($this->env, $this->env->getExtension('Symfony\Bridge\Twig\Extension\AssetExtension')->getAssetUrl("js/bootstrap-datetimepicker.min.js"), "html", null, true);
        echo "\"></script>
";
        
        $__internal_add0ceff660eb97f6b4dde63065278b5086ecc4faaebb6d4a88115cc662ed340->leave($__internal_add0ceff660eb97f6b4dde63065278b5086ecc4faaebb6d4a88115cc662ed340_prof);

        
        $__internal_fa261fada51624c460a2443c0900a3ccf1757fe773e371473870d801244fc16f->leave($__internal_fa261fada51624c460a2443c0900a3ccf1757fe773e371473870d801244fc16f_prof);

    }

    public function getTemplateName()
    {
        return "base.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  279 => 62,  275 => 61,  271 => 60,  266 => 59,  257 => 58,  242 => 51,  233 => 50,  216 => 44,  204 => 45,  202 => 44,  198 => 42,  189 => 41,  166 => 26,  160 => 22,  151 => 21,  134 => 19,  122 => 14,  117 => 13,  108 => 12,  90 => 11,  77 => 64,  75 => 58,  72 => 57,  70 => 50,  66 => 48,  64 => 41,  60 => 39,  58 => 21,  53 => 19,  46 => 16,  44 => 12,  40 => 11,  33 => 6,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{#
   This is the base template used as the application layout which contains the
   common elements and decorates all the other templates.
   See http://symfony.com/doc/current/book/templating.html#template-inheritance-and-layouts
#}
<!DOCTYPE html>
<html lang=\"en-US\">
<head>
    <meta charset=\"UTF-8\"/>
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\"/>
    <title>{% block title %}Calculator{% endblock %}</title>
    {% block stylesheets %}
        <link rel=\"stylesheet\" href=\"{{ asset('css/style.css') }}\">
        <link rel=\"stylesheet\" href=\"{{ asset('css/bootstrap-datetimepicker.min.css') }}\">
    {% endblock %}
    <link rel=\"icon\" type=\"image/x-icon\" href=\"{{ asset('favicon.ico') }}\"/>
</head>

<body id=\"{% block body_id %}{% endblock %}\">

{% block header %}
    <header>
        <div class=\"navbar navbar-default navbar-static-top\" role=\"navigation\">
            <div class=\"container\">
                <div class=\"navbar-header\">
                    <a href=\"{{ path('index') }}\" class=\"navbar-brand\">CALCULATOR</a>

                    <button type=\"button\" class=\"navbar-toggle\" data-toggle=\"collapse\" data-target=\".navbar-collapse\">
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                        <span class=\"icon-bar\"></span>
                    </button>
                </div>

            </div>
        </div>
    </header>
{% endblock %}

<div class=\"container body-container\">
    {% block body %}
        <div class=\"row\">
            <div id=\"main\" class=\"col-sm-9\">
                {% block main %}{% endblock %}
            </div>
        </div>
    {% endblock %}
</div>

{% block footer %}
    <footer>
        <div class=\"container modal-footer\">
            <p>&copy; 2018 - Software University Foundation</p>
        </div>
    </footer>
{% endblock %}

{% block javascripts %}
    <script src=\"{{ asset('js/jquery-2.2.4.min.js') }}\"></script>
    <script src=\"{{ asset('js/moment.min.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap.js') }}\"></script>
    <script src=\"{{ asset('js/bootstrap-datetimepicker.min.js') }}\"></script>
{% endblock %}

</body>
</html>
", "base.html.twig", "C:\\Users\\GeorgiGeorgiev\\Desktop\\CalculatorPHP\\app\\Resources\\views\\base.html.twig");
    }
}
