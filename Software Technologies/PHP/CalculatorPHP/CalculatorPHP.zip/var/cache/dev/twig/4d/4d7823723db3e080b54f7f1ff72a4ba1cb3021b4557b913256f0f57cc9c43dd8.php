<?php

/* @WebProfiler/Collector/exception.html.twig */
class __TwigTemplate_99b2a225cb70aa4a8d48984f92fa0c34ec0fea32a96ff1e63d94ed7465a2ded8 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/exception.html.twig", 1);
        $this->blocks = array(
            'head' => array($this, 'block_head'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_6b10d6b65cfe8bb38174beddc53c6aef842465e888c00d7f30f84ad78fd0399f = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6b10d6b65cfe8bb38174beddc53c6aef842465e888c00d7f30f84ad78fd0399f->enter($__internal_6b10d6b65cfe8bb38174beddc53c6aef842465e888c00d7f30f84ad78fd0399f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $__internal_f434efd11ccfb9bb3c59cfbe81dc59f31e21fbd34e64b5c06e252b18e3936cbd = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f434efd11ccfb9bb3c59cfbe81dc59f31e21fbd34e64b5c06e252b18e3936cbd->enter($__internal_f434efd11ccfb9bb3c59cfbe81dc59f31e21fbd34e64b5c06e252b18e3936cbd_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/exception.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_6b10d6b65cfe8bb38174beddc53c6aef842465e888c00d7f30f84ad78fd0399f->leave($__internal_6b10d6b65cfe8bb38174beddc53c6aef842465e888c00d7f30f84ad78fd0399f_prof);

        
        $__internal_f434efd11ccfb9bb3c59cfbe81dc59f31e21fbd34e64b5c06e252b18e3936cbd->leave($__internal_f434efd11ccfb9bb3c59cfbe81dc59f31e21fbd34e64b5c06e252b18e3936cbd_prof);

    }

    // line 3
    public function block_head($context, array $blocks = array())
    {
        $__internal_8ca76c64bd8af1350c113563b38671ffcaea315373fef03e7fe7b5f7bcfcb9d5 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_8ca76c64bd8af1350c113563b38671ffcaea315373fef03e7fe7b5f7bcfcb9d5->enter($__internal_8ca76c64bd8af1350c113563b38671ffcaea315373fef03e7fe7b5f7bcfcb9d5_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        $__internal_7014fa09fa3c217a3d360b56380d24c084fbff45bd36b940454c47daf6522b62 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7014fa09fa3c217a3d360b56380d24c084fbff45bd36b940454c47daf6522b62->enter($__internal_7014fa09fa3c217a3d360b56380d24c084fbff45bd36b940454c47daf6522b62_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "head"));

        // line 4
        echo "    ";
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 5
            echo "        <style>
            ";
            // line 6
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception_css", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </style>
    ";
        }
        // line 9
        echo "    ";
        $this->displayParentBlock("head", $context, $blocks);
        echo "
";
        
        $__internal_7014fa09fa3c217a3d360b56380d24c084fbff45bd36b940454c47daf6522b62->leave($__internal_7014fa09fa3c217a3d360b56380d24c084fbff45bd36b940454c47daf6522b62_prof);

        
        $__internal_8ca76c64bd8af1350c113563b38671ffcaea315373fef03e7fe7b5f7bcfcb9d5->leave($__internal_8ca76c64bd8af1350c113563b38671ffcaea315373fef03e7fe7b5f7bcfcb9d5_prof);

    }

    // line 12
    public function block_menu($context, array $blocks = array())
    {
        $__internal_db1b686ba06f2a04926f61ccededd5983bce3da61d431bd2a1406398b26240b4 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_db1b686ba06f2a04926f61ccededd5983bce3da61d431bd2a1406398b26240b4->enter($__internal_db1b686ba06f2a04926f61ccededd5983bce3da61d431bd2a1406398b26240b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_12a4e9cc80ea4f8154188726aee917899d2091a57b4ae19872ef157560d845a2 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_12a4e9cc80ea4f8154188726aee917899d2091a57b4ae19872ef157560d845a2->enter($__internal_12a4e9cc80ea4f8154188726aee917899d2091a57b4ae19872ef157560d845a2_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 13
        echo "    <span class=\"label ";
        echo (($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) ? ("label-status-error") : ("disabled"));
        echo "\">
        <span class=\"icon\">";
        // line 14
        echo twig_include($this->env, $context, "@WebProfiler/Icon/exception.svg");
        echo "</span>
        <strong>Exception</strong>
        ";
        // line 16
        if ($this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 17
            echo "            <span class=\"count\">
                <span>1</span>
            </span>
        ";
        }
        // line 21
        echo "    </span>
";
        
        $__internal_12a4e9cc80ea4f8154188726aee917899d2091a57b4ae19872ef157560d845a2->leave($__internal_12a4e9cc80ea4f8154188726aee917899d2091a57b4ae19872ef157560d845a2_prof);

        
        $__internal_db1b686ba06f2a04926f61ccededd5983bce3da61d431bd2a1406398b26240b4->leave($__internal_db1b686ba06f2a04926f61ccededd5983bce3da61d431bd2a1406398b26240b4_prof);

    }

    // line 24
    public function block_panel($context, array $blocks = array())
    {
        $__internal_98a8d66f19a713fe3885bda4091adcd6b6bcf254f50c0ae865b8104cc1dfccc6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_98a8d66f19a713fe3885bda4091adcd6b6bcf254f50c0ae865b8104cc1dfccc6->enter($__internal_98a8d66f19a713fe3885bda4091adcd6b6bcf254f50c0ae865b8104cc1dfccc6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_722524f4e4d038c6620496d6e53d4f0079a406c16c3fa7a45bd5dc4db617c4b3 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_722524f4e4d038c6620496d6e53d4f0079a406c16c3fa7a45bd5dc4db617c4b3->enter($__internal_722524f4e4d038c6620496d6e53d4f0079a406c16c3fa7a45bd5dc4db617c4b3_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 25
        echo "    <h2>Exceptions</h2>

    ";
        // line 27
        if ( !$this->getAttribute(($context["collector"] ?? $this->getContext($context, "collector")), "hasexception", array())) {
            // line 28
            echo "        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    ";
        } else {
            // line 32
            echo "        <div class=\"sf-reset\">
            ";
            // line 33
            echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_exception", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
            echo "
        </div>
    ";
        }
        
        $__internal_722524f4e4d038c6620496d6e53d4f0079a406c16c3fa7a45bd5dc4db617c4b3->leave($__internal_722524f4e4d038c6620496d6e53d4f0079a406c16c3fa7a45bd5dc4db617c4b3_prof);

        
        $__internal_98a8d66f19a713fe3885bda4091adcd6b6bcf254f50c0ae865b8104cc1dfccc6->leave($__internal_98a8d66f19a713fe3885bda4091adcd6b6bcf254f50c0ae865b8104cc1dfccc6_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/exception.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  138 => 33,  135 => 32,  129 => 28,  127 => 27,  123 => 25,  114 => 24,  103 => 21,  97 => 17,  95 => 16,  90 => 14,  85 => 13,  76 => 12,  63 => 9,  57 => 6,  54 => 5,  51 => 4,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block head %}
    {% if collector.hasexception %}
        <style>
            {{ render(path('_profiler_exception_css', { token: token })) }}
        </style>
    {% endif %}
    {{ parent() }}
{% endblock %}

{% block menu %}
    <span class=\"label {{ collector.hasexception ? 'label-status-error' : 'disabled' }}\">
        <span class=\"icon\">{{ include('@WebProfiler/Icon/exception.svg') }}</span>
        <strong>Exception</strong>
        {% if collector.hasexception %}
            <span class=\"count\">
                <span>1</span>
            </span>
        {% endif %}
    </span>
{% endblock %}

{% block panel %}
    <h2>Exceptions</h2>

    {% if not collector.hasexception %}
        <div class=\"empty\">
            <p>No exception was thrown and caught during the request.</p>
        </div>
    {% else %}
        <div class=\"sf-reset\">
            {{ render(path('_profiler_exception', { token: token })) }}
        </div>
    {% endif %}
{% endblock %}
", "@WebProfiler/Collector/exception.html.twig", "C:\\Users\\GeorgiGeorgiev\\Desktop\\CalculatorPHP\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\exception.html.twig");
    }
}
