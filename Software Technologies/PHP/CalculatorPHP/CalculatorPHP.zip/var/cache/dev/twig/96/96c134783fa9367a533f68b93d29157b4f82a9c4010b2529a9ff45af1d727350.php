<?php

/* @WebProfiler/Collector/router.html.twig */
class __TwigTemplate_d496044effa4cc39ce51801babe801f9942ccc5fec27a124c696ada197249fa7 extends Twig_Template
{
    public function __construct(Twig_Environment $env)
    {
        parent::__construct($env);

        // line 1
        $this->parent = $this->loadTemplate("@WebProfiler/Profiler/layout.html.twig", "@WebProfiler/Collector/router.html.twig", 1);
        $this->blocks = array(
            'toolbar' => array($this, 'block_toolbar'),
            'menu' => array($this, 'block_menu'),
            'panel' => array($this, 'block_panel'),
        );
    }

    protected function doGetParent(array $context)
    {
        return "@WebProfiler/Profiler/layout.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = array())
    {
        $__internal_681be84ee95ab483545b69af0d6a05cc473f6ebb06ebacc757e43a8d3128def6 = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_681be84ee95ab483545b69af0d6a05cc473f6ebb06ebacc757e43a8d3128def6->enter($__internal_681be84ee95ab483545b69af0d6a05cc473f6ebb06ebacc757e43a8d3128def6_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $__internal_f07de5eb858a90383b9057444b5ce5b2eccb8ed262288eaea9438f17498445b4 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_f07de5eb858a90383b9057444b5ce5b2eccb8ed262288eaea9438f17498445b4->enter($__internal_f07de5eb858a90383b9057444b5ce5b2eccb8ed262288eaea9438f17498445b4_prof = new Twig_Profiler_Profile($this->getTemplateName(), "template", "@WebProfiler/Collector/router.html.twig"));

        $this->parent->display($context, array_merge($this->blocks, $blocks));
        
        $__internal_681be84ee95ab483545b69af0d6a05cc473f6ebb06ebacc757e43a8d3128def6->leave($__internal_681be84ee95ab483545b69af0d6a05cc473f6ebb06ebacc757e43a8d3128def6_prof);

        
        $__internal_f07de5eb858a90383b9057444b5ce5b2eccb8ed262288eaea9438f17498445b4->leave($__internal_f07de5eb858a90383b9057444b5ce5b2eccb8ed262288eaea9438f17498445b4_prof);

    }

    // line 3
    public function block_toolbar($context, array $blocks = array())
    {
        $__internal_6cfb997a14bd3f6e0ef5bcbcc94e3e4123c790195112978c075e4eb1d07e2b3c = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_6cfb997a14bd3f6e0ef5bcbcc94e3e4123c790195112978c075e4eb1d07e2b3c->enter($__internal_6cfb997a14bd3f6e0ef5bcbcc94e3e4123c790195112978c075e4eb1d07e2b3c_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        $__internal_881f8cf6e0f93ffc03e6e3f37fe392de3a5199bab7a20d113723243f4d28d139 = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_881f8cf6e0f93ffc03e6e3f37fe392de3a5199bab7a20d113723243f4d28d139->enter($__internal_881f8cf6e0f93ffc03e6e3f37fe392de3a5199bab7a20d113723243f4d28d139_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "toolbar"));

        
        $__internal_881f8cf6e0f93ffc03e6e3f37fe392de3a5199bab7a20d113723243f4d28d139->leave($__internal_881f8cf6e0f93ffc03e6e3f37fe392de3a5199bab7a20d113723243f4d28d139_prof);

        
        $__internal_6cfb997a14bd3f6e0ef5bcbcc94e3e4123c790195112978c075e4eb1d07e2b3c->leave($__internal_6cfb997a14bd3f6e0ef5bcbcc94e3e4123c790195112978c075e4eb1d07e2b3c_prof);

    }

    // line 5
    public function block_menu($context, array $blocks = array())
    {
        $__internal_ee31270aa260e8f9a3751de737615a4a59a410ceffdb285204b12bbd594aea0a = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ee31270aa260e8f9a3751de737615a4a59a410ceffdb285204b12bbd594aea0a->enter($__internal_ee31270aa260e8f9a3751de737615a4a59a410ceffdb285204b12bbd594aea0a_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        $__internal_de52a1ebdaeffc2e1d90b8041ed306a2d1b6bc89514b7796c5b4243797df3b8e = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_de52a1ebdaeffc2e1d90b8041ed306a2d1b6bc89514b7796c5b4243797df3b8e->enter($__internal_de52a1ebdaeffc2e1d90b8041ed306a2d1b6bc89514b7796c5b4243797df3b8e_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "menu"));

        // line 6
        echo "<span class=\"label\">
    <span class=\"icon\">";
        // line 7
        echo twig_include($this->env, $context, "@WebProfiler/Icon/router.svg");
        echo "</span>
    <strong>Routing</strong>
</span>
";
        
        $__internal_de52a1ebdaeffc2e1d90b8041ed306a2d1b6bc89514b7796c5b4243797df3b8e->leave($__internal_de52a1ebdaeffc2e1d90b8041ed306a2d1b6bc89514b7796c5b4243797df3b8e_prof);

        
        $__internal_ee31270aa260e8f9a3751de737615a4a59a410ceffdb285204b12bbd594aea0a->leave($__internal_ee31270aa260e8f9a3751de737615a4a59a410ceffdb285204b12bbd594aea0a_prof);

    }

    // line 12
    public function block_panel($context, array $blocks = array())
    {
        $__internal_ede3bef5d8d32b61d3c381f89bf1dba3b0bebc53b4e2a1b3e608b85c6c90bfad = $this->env->getExtension("Symfony\\Bundle\\WebProfilerBundle\\Twig\\WebProfilerExtension");
        $__internal_ede3bef5d8d32b61d3c381f89bf1dba3b0bebc53b4e2a1b3e608b85c6c90bfad->enter($__internal_ede3bef5d8d32b61d3c381f89bf1dba3b0bebc53b4e2a1b3e608b85c6c90bfad_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        $__internal_7b33d5c7f2f9a99fd2f03da2c6fee614c9f5514197d930acc455b1fcd6e1dd3f = $this->env->getExtension("Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension");
        $__internal_7b33d5c7f2f9a99fd2f03da2c6fee614c9f5514197d930acc455b1fcd6e1dd3f->enter($__internal_7b33d5c7f2f9a99fd2f03da2c6fee614c9f5514197d930acc455b1fcd6e1dd3f_prof = new Twig_Profiler_Profile($this->getTemplateName(), "block", "panel"));

        // line 13
        echo "    ";
        echo $this->env->getRuntime('Symfony\Bridge\Twig\Extension\HttpKernelRuntime')->renderFragment($this->env->getExtension('Symfony\Bridge\Twig\Extension\RoutingExtension')->getPath("_profiler_router", array("token" => ($context["token"] ?? $this->getContext($context, "token")))));
        echo "
";
        
        $__internal_7b33d5c7f2f9a99fd2f03da2c6fee614c9f5514197d930acc455b1fcd6e1dd3f->leave($__internal_7b33d5c7f2f9a99fd2f03da2c6fee614c9f5514197d930acc455b1fcd6e1dd3f_prof);

        
        $__internal_ede3bef5d8d32b61d3c381f89bf1dba3b0bebc53b4e2a1b3e608b85c6c90bfad->leave($__internal_ede3bef5d8d32b61d3c381f89bf1dba3b0bebc53b4e2a1b3e608b85c6c90bfad_prof);

    }

    public function getTemplateName()
    {
        return "@WebProfiler/Collector/router.html.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  94 => 13,  85 => 12,  71 => 7,  68 => 6,  59 => 5,  42 => 3,  11 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Twig_Source("{% extends '@WebProfiler/Profiler/layout.html.twig' %}

{% block toolbar %}{% endblock %}

{% block menu %}
<span class=\"label\">
    <span class=\"icon\">{{ include('@WebProfiler/Icon/router.svg') }}</span>
    <strong>Routing</strong>
</span>
{% endblock %}

{% block panel %}
    {{ render(path('_profiler_router', { token: token })) }}
{% endblock %}
", "@WebProfiler/Collector/router.html.twig", "C:\\Users\\GeorgiGeorgiev\\Desktop\\CalculatorPHP\\vendor\\symfony\\symfony\\src\\Symfony\\Bundle\\WebProfilerBundle\\Resources\\views\\Collector\\router.html.twig");
    }
}
